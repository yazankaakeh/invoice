<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class invoice extends Model
{
     protected $guarded =['id'];
}
