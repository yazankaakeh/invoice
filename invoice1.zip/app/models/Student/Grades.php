<?php

namespace App\models\Student;

use Illuminate\Database\Eloquent\Model;

class Grades extends Model
{
     protected $guarded =['id'];
}
